#include "map.h"

#include <iostream>
#include <vector>
#include <utility>
#include <random>
#include "raylib.h"
#include <string>
#include <ctime>
#include "agent.h"
#include <sstream>
#include <set>
#include <map>
#include <queue>
#include <algorithm>

void Map::saveGrid(std::stringstream* outputString) {
    (*outputString) << width << " " << height << "\n";
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            (*outputString) << grid[y][x];
        }
        (*outputString) << "\n";
    }
}

void Map::saveAgents(std::stringstream* outputString) {
    (*outputString) << agentCount << "\n";
    for (int i = 0; i < agentCount; i++) {
        Agent &agent = agents[i];
        (*outputString) << agent.position.x << " " 
            << agent.position.y << " " << agent.loaderCurrent << " "
            << agent.unloaderCurrent << " " << agent.direction << " " 
            << agent.r << " " << agent.g << " " << agent.b 
            << "\n";
        int length = agentPathSizes[i];
        if (length < 0){
            length = 0;
        }
        (*outputString) << length << "\n";
        for (int j = 0; j < length; j++){
            Position& p = agentPaths[i][j];
            (*outputString) << p.x << " " << p.y;
        }
        (*outputString) << "\n";

    }
}

void Map::saveDocks(std::stringstream* outputString){
    (*outputString) << loaderCount << "\n";
    for (int i = 0; i < loaderCount; i++) {
        Position position = loaderPosition[i];
        (*outputString) << position.x << position.y << "\n";
    }
    (*outputString) << unloaderCount << "\n";
    for (int i = 0; i < unloaderCount; i++) {
        Position position = unloaderPosition[i];
        (*outputString) << position.x << position.y << "\n";
    }
}

void Map::save(const std::string& baseFilename) {
    if (!DirectoryExists("saved_map")) {
        MakeDirectory("saved_map");
    }
    std::string uniqueFilename = getUniqueFilename("saved_map/" + baseFilename);
    std::stringstream outputString;
    saveGrid(&outputString);
    saveAgents(&outputString);
    saveDocks(&outputString);
    std::string protoRes = outputString.str();
    char* res = const_cast<char*>(protoRes.c_str());
    if (!SaveFileText(uniqueFilename.c_str(), res)) {
        throw std::runtime_error("Failed to save file: " + uniqueFilename);
    }
}
void Map::loadGrid(std::stringstream* inputString) {
    if(grid != nullptr){
        for (int y = 0; y < height; y++) {
            delete[] grid[y];
        }
        delete[] grid;
    }
    (*inputString) >> width >> height;
    grid = new char*[height];
    for (int y = 0; y < height; y++) {
        grid[y] = new char[width];
        for (int x = 0; x < width; x++) {
            (*inputString) >> grid[y][x];
        }
    }
}

void Map::loadAgents(std::stringstream* inputString) {
    (*inputString) >> agentCount;
    if (agents!= nullptr) {
        delete[] agents;
    }
    agents = new Agent[agentCount];
    if (agentPaths != nullptr)    {
        for (int i = 0; i < agentCount; i++) {
            if (agentPaths[i] != nullptr)           {
                delete[] agentPaths;
            }
        }
    }
    agentPaths = new Position*[agentCount];
    if (agentPathSizes != nullptr) {
        delete[] agentPathSizes;
    }
    agentPathSizes = new int[agentCount];

    for (int i = 0; i < agentCount; i++) {
        Agent& agent = agents[i];
        (*inputString) >> agent.position.x >> agent.position.y >> agent.loaderCurrent
            >> agent.unloaderCurrent >> agent.direction >> agent.r >> agent.g >> agent.b;

        int length;
        (*inputString) >> length;
        agentPathSizes[i] = length;
        agentPaths[i] = new Position[length];
        for (int j = 0; j < length; j++) {
            Position& p = agentPaths[i][j];
            (*inputString) >> p.x >> p.y;
        }
    }
}

void Map::loadDocks(std::stringstream* inputString) {
    if (loaderPosition != nullptr)    {
        delete[] loaderPosition;
    }
    (*inputString) >> loaderCount;
    loaderPosition = new Position[loaderCount];

    for (int i = 0; i < loaderCount; i++) {
        (*inputString) >> loaderPosition[i].x >> loaderPosition[i].y;
    }
    if (unloaderPosition != nullptr) {
        delete[] unloaderPosition;
    }
    (*inputString) >> unloaderCount;
    unloaderPosition = new Position[unloaderCount];

    for (int i = 0; i < unloaderCount; i++) {
        (*inputString) >> unloaderPosition[i].x >> unloaderPosition[i].y;
    }
}

void Map::loadData(const std::string& filename, std::stringstream& inputString) {
    char* data = LoadFileText(("saved_map/" + filename).data());
    if (data == nullptr) {
        std::stringstream errorString;
        errorString << "Failed to load map at " << filename << std::endl;
        TraceLog(LOG_ERROR, errorString.str().c_str());
        throw std::runtime_error(errorString.str().c_str());
    }
    inputString = std::stringstream(data);
}

// load fill Map according filename in saved_map dictionary
void Map::load(const std::string& filename) {
    std::stringstream inputString;
    loadGrid(&inputString);
    loadAgents(&inputString);
    loadDocks(&inputString);
}

Map::Map(int width, int height, int agentCount, int obstacleCount, int loaderCount, int unloaderCount) : width(width), height(height), 
loaderCount(loaderCount), unloaderCount(unloaderCount), obstacleCount(obstacleCount), agentCount(agentCount){
    grid = nullptr; loaderPosition = nullptr;
    unloaderPosition = nullptr; agentPathSizes = nullptr; 
    agentPaths = nullptr; agents = nullptr;
    reset();
}
Map::Map() {
    width = 0; height = 0; loaderCount = 0; unloaderCount = 0;
    grid = nullptr;  grid = nullptr; loaderPosition = nullptr;
    unloaderPosition = nullptr; agentPathSizes = nullptr;
    agentPaths = nullptr;   agents = nullptr;
}

Map::~Map() {
    deleteGrid();
}

void Map::reset() {
    deleteGrid();
    srand(time(nullptr));
    while (is_need_init()) {
        init();
    }
}

std::string Map::getUniqueFilename(const std::string& base) {
    std::string filename = base;
    std::string name = std::string(GetFileNameWithoutExt(filename.c_str()));
    int counter = 0;
    while (FileExists(filename.c_str())) {
        counter++;
        filename = name + std::to_string(counter) + ".txt";
    }
    return filename;
}
bool Map::isConnected() {
    std::pair<int, int> start = std::pair<int, int>{ -1, -1 };
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            if (grid[y][x] != OBSTACLE_SYMBOL) {
                start = { x, y };
                break;
            }
        }
        if (start.first != -1) break;
    }
    if (start.first == -1) {
        return false;
    }
    std::vector<std::vector<bool>> visited = std::vector<std::vector<bool>>(height, std::vector<bool>(width));

    std::vector<std::pair<int, int>> stack;
    stack.push_back(start);
    visited[start.second][start.first] = true;

    while (!stack.empty()) {
        auto c = stack.back();
        stack.pop_back();
        const std::vector<std::pair<int, int>> directions = {
            {0, 1}, {1, 0}, {0, -1}, {-1, 0}
        };
        for (const auto& d : directions) {
            int nx = c.first + d.first;
            int ny = c.second + d.second;
            if (nx >= 0 && nx < width && ny >= 0 && ny < height && grid[ny][nx] != OBSTACLE_SYMBOL) {
                if (!visited[ny][nx]) {
                    visited[ny][nx] = true;
                    stack.emplace_back(nx, ny);
                }
            }
        }
    }
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            if (grid[y][x] != OBSTACLE_SYMBOL && !visited[y][x]) {
                return false;
            }
        }
    }
    return true;
}

bool Map::is_need_init() {
    if (grid == nullptr || agents == nullptr || loaderPosition == nullptr || unloaderPosition == nullptr) {
        return true;
    }
    // H�bkov� preh�ad�vanie
    return !isConnected();
}

void Map::findFree(int& x, int& y) {
    do {
        x = rand() % width;
        y = rand() % height;
    } while (grid[y][x] != '.');
}

bool Map::isAgentIn(int x, int y, int i) {
    for (int j = 0; j < i; j++){
        if (agents[j].position.x == x && agents[j].position.y == y) {
            return true;
        }
    }
    return false;
}

void Map::initAgents() {
    if (agents != nullptr) {
        delete[] agents;
    }
    agents = new Agent[agentCount];
    for (int i = 0; i < agentCount; i++) {
        int x, y;
        while (true) {
            findFree(x, y);
            if (isAgentIn(x,y,i) == false){
                break;
            }
        }
        Agent& a = agents[i];
        a.position = Position{ x,y };
        a.direction = AGENT_LOADER;
        a.loaderCurrent = 0;
        a.unloaderCurrent = 0;
    }
}

void Map::initUnloader() {
    if (unloaderPosition != nullptr) {
        delete[] unloaderPosition;
    }
    unloaderPosition = new Position[unloaderCount];
    for (int i = 0; i < unloaderCount; i++) {
        int x, y;
        findFree(x, y);
        grid[y][x] = UNLOADER_SYMBOL;
        unloaderPosition[i].x = x;
        unloaderPosition[i].y = y;
    }
}

void Map::initLoader() {
    if (loaderPosition != nullptr) {
        delete[] loaderPosition;
    }
    loaderPosition = new Position[loaderCount];
    for (int i = 0; i < loaderCount; i++) {
        int x, y;
        findFree(x, y);
        grid[y][x] = LOADER_SYMBOL;
        loaderPosition[i].x = x;
        loaderPosition[i].y = y;
    }
}

void Map::initObstacle() {
    for (int i = 0; i < obstacleCount; i++) {
        int x, y;
        findFree(x, y);
        grid[y][x] = OBSTACLE_SYMBOL;
    }
}

void Map::initGrid() {
    if (grid != nullptr) {
        deleteGrid();
    }
    grid = new char* [height];
    for (int i = 0; i < height; i++) {
        grid[i] = new char[width];
        for (int j = 0; j < width; j++) {
            grid[i][j] = FREEFIELD_SYMBOL; 
        }
    }
}

void Map::init() {
    initGrid();
    initObstacle();
    initLoader();
    initUnloader();
    initAgents();
}

void Map::deleteGrid() {
    if (grid == nullptr){
        return;
    }
    for (int i = 0; i < height; i++) {
        delete[] grid[i];
    }
    delete[] grid;
}

// ===================================== draw ====================

void Map::drawGrid(int cellWidth, int cellHeight) {
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            Rectangle rect = Rectangle{ static_cast<float>(x * cellWidth), static_cast<float>(y * cellHeight), static_cast<float>(cellWidth), static_cast<float>(cellHeight) };
            if (grid[y][x] == OBSTACLE_SYMBOL) {
                DrawRectangleRec(rect, BLACK);
            }
            else if (grid[y][x] == LOADER_SYMBOL) {
                DrawRectangleRec(rect, LIGHTGRAY);
                DrawText("I", static_cast<float>(cellWidth) / 4 + rect.x, static_cast<float>(cellHeight) / 4 + rect.y, 20, DARKGRAY);
            }
            else if (grid[y][x] == UNLOADER_SYMBOL) {
                DrawRectangleRec(rect, LIGHTGRAY);
                DrawText("O", rect.x + static_cast<float>(cellWidth) / 4, rect.y + static_cast<float>(cellHeight) / 4, 20, DARKGRAY);
            }
            else {
                DrawRectangleLinesEx(rect, 1, RED);
            }
        }
    }
}

void Map::drawAgentPath(const int agentIndex, int cellWidth, int cellHeight) {
    if (agentPaths[agentIndex] == nullptr || agentPathSizes[agentIndex] <= 0) {
        return; 
    }
    Color pathColor = { 0, 255, 0, 60 };
    Position *path = agentPaths[agentIndex];
    for (int i = 0; i < agentPathSizes[agentIndex]; i++) {
        Position& pos = path[i];
        Rectangle rect = {
            static_cast<float>(pos.x * cellWidth),
            static_cast<float>(pos.y * cellHeight),
            static_cast<float>(cellWidth),
            static_cast<float>(cellHeight)
        };
        DrawRectangleRec(rect, pathColor);
    }
}

void Map::drawAgents(int cellWidth, int cellHeight) {
    for (int i = 0; i < agentCount; i++) {
        Agent agent = agents[i];
        int agentX = agent.position.x * cellWidth + cellWidth / 2;
        int agentY = agent.position.y * cellHeight + cellHeight / 2;
        DrawCircle(agentX, agentY, static_cast<float>(cellWidth) / 4, GREEN);
        if (agent.direction == AGENT_LOADER) {
            DrawCircle(agentX, agentY, static_cast<float>(cellWidth) / 8, RED);
        }
        else {
            DrawCircle(agentX, agentY, static_cast<float>(cellWidth) / 8, { agent.r, agent.g, agent.b, 255 });
        }
    }
    for (int i = 0; i < agentCount; i++) {
        drawAgentPath(i, cellWidth, cellHeight);
    }
}

void Map::draw(int screenWidth, int screenHeight) {
    int cellWidth = screenWidth / width;
    int cellHeight = screenHeight / height;
    drawGrid(cellWidth, cellHeight);
    drawAgents(cellWidth, cellHeight);
    drawSelect(cellWidth, cellHeight);
}

void Map::drawSelect(int cellWidth, int cellHeight){
    if (selected.x == -1) {
        return;
    }
    Color selectedColor = { 255, 0, 0, 191 }; // �erven� s 75% neprieh�adnos�ou (191 = 75% z 255)
    Rectangle selectedRect = {
        static_cast<float>(selected.x * cellWidth),
        static_cast<float>(selected.y * cellHeight),
        static_cast<float>(cellWidth),
        static_cast<float>(cellHeight)
    };

    DrawRectangleLinesEx(selectedRect, 3, selectedColor);
}

