#pragma once
#include <map>
#include <string>
#include "agent.h"
#define LOADER_SYMBOL 'I'
#define UNLOADER_SYMBOL 'O'
#define OBSTACLE_SYMBOL '#'
#define FREEFIELD_SYMBOL '.'

// nno map symbol
#define AGENT_SYMBOL 'A'
Position selected = Position{ -1,-1 };

struct Map {
    int width, height, loaderCount, unloaderCount, obstacleCount, agentCount;

    char** grid = nullptr;

    Position* loaderPosition = nullptr;
    Position* unloaderPosition = nullptr;

    int* agentPathSizes = nullptr;
    Position** agentPaths = nullptr;
    Agent* agents = nullptr;

    bool is_need_init();
    bool isAgentIn(int x, int y, int i) ;
    void initAgents();
    void initUnloader();
    void initLoader();
    void findFree(int& x, int& y);
    void initObstacle();
    void initGrid();
    void init();
    void deleteGrid();

    void reset();


    void saveGrid(std::stringstream* outputString);
    void saveAgents(std::stringstream* outputString);
    void saveDocks(std::stringstream* outputString);
    void save(const std::string& baseFilename);

    void loadData(const std::string& filename, std::stringstream& inputString);
    void loadDocks(std::stringstream* inputString);
    void loadAgents(std::stringstream* inputString);
    void loadGrid(std::stringstream* input_string);
    void load(const std::string& filename);

    void drawGrid(int cellWidth, int cellHeight);
    void drawAgents(int cellWidth, int cellHeight);
    void drawAgentPath(const int agentIndex, int cellWidth, int cellHeight);
    void drawSelect(int cellWidth, int cellHeight);
    void draw(int screenWidth, int screenHeight);

    Map(int width, int height, int agentCount, int obstacleCount, int loaderCount, int unloaderCount);
    Map();
    ~Map();
    bool isConnected();
    std::string getUniqueFilename(const std::string& base);
};
