/*

#include <sycl/sycl.hpp>
#include <limits>
#include <vector>
#include <iostream>

#define INF std::numeric_limits<int>::max()

using namespace sycl;

struct Position {
    int x, y;
    bool operator==(const Position& other) const { return x == other.x && y == other.y; }
};

struct Agent {
    Position position;
    Position goal;
};

struct Map {
    int width, height;
    char* grid;  
    Position* agentPaths;
    int* agentPathSizes;
};

// Device pam� pre A*
struct GPUData {
    char* d_grid = nullptr;
    Position* d_agentPaths = nullptr;
    int* d_agentPathSizes = nullptr;
    Agent* d_agents = nullptr;
};

GPUData gpuData;
queue q;

void init(Map& m) {
    // **Alok�cia nemennej pam�te**
    gpuData.d_grid = malloc_device<char>(m.width * m.height, q);
    gpuData.d_agentPaths = malloc_device<Position>(m.agentCount * m.width * m.height, q);
    gpuData.d_agentPathSizes = malloc_device<int>(m.agentCount, q);
    gpuData.d_agents = malloc_device<Agent>(m.agentCount, q);

    // **Kop�rovanie gridu do GPU**
    q.memcpy(gpuData.d_grid, m.grid, m.width * m.height * sizeof(char)).wait();
}

void destroy() {
    // **Uvo�nenie pam�te na GPU**
    sycl::free(gpuData.d_grid, q);
    sycl::free(gpuData.d_agentPaths, q);
    sycl::free(gpuData.d_agentPathSizes, q);
    sycl::free(gpuData.d_agents, q);
}

// Manhattan heuristika
int heuristic(Position a, Position b) {
    return abs(a.x - b.x) + abs(a.y - b.y);
}

void runAstar(Map& m, Agent* agents) {
    // **Kop�rovanie agentov do GPU**
    q.memcpy(gpuData.d_agents, agents, m.agentCount * sizeof(Agent)).wait();

    // **Spustenie GPU kernelu**
    q.submit([&](handler& h) {
        h.parallel_for(m.agentCount, [=](id<1> agentID) {
            Position start = gpuData.d_agents[agentID].position;
            Position goal = gpuData.d_agents[agentID].goal;

            int width = m.width;
            int height = m.height;
            int maxPathLen = width * height;

            int g_costs[256 * 256];
            int f_costs[256 * 256];
            bool visited[256 * 256] = {false};
            Position openList[256 * 256];

            for (int i = 0; i < width * height; i++) {
                g_costs[i] = INF;
                f_costs[i] = INF;
            }
            g_costs[start.y * width + start.x] = 0;
            f_costs[start.y * width + start.x] = heuristic(start, goal);

            int openListSize = 0;
            openList[openListSize++] = start;

            Position directions[4] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
            Position cameFrom[256 * 256];

            while (openListSize > 0) {
                // Min-heap ru�ne: vyberieme uzol s najni���m f-cost
                int bestIndex = 0;
                for (int i = 1; i < openListSize; i++) {
                    int idx1 = openList[i].y * width + openList[i].x;
                    int idx2 = openList[bestIndex].y * width + openList[bestIndex].x;
                    if (f_costs[idx1] < f_costs[idx2]) bestIndex = i;
                }

                Position current = openList[bestIndex];
                openList[bestIndex] = openList[--openListSize];

                if (visited[current.y * width + current.x]) continue;
                visited[current.y * width + current.x] = true;

                if (current == goal) break;

                for (int i = 0; i < 4; i++) {
                    Position neighbor = {current.x + directions[i].x, current.y + directions[i].y};
                    if (neighbor.x < 0 || neighbor.x >= width || neighbor.y < 0 || neighbor.y >= height) continue;
                    if (gpuData.d_grid[neighbor.y * width + neighbor.x] == '#') continue;

                    int new_g = g_costs[current.y * width + current.x] + 1;
                    if (new_g < g_costs[neighbor.y * width + neighbor.x]) {
                        g_costs[neighbor.y * width + neighbor.x] = new_g;
                        f_costs[neighbor.y * width + neighbor.x] = new_g + heuristic(neighbor, goal);
                        cameFrom[neighbor.y * width + neighbor.x] = current;
                        openList[openListSize++] = neighbor;
                    }
                }
            }

            Position pathBuffer[256 * 256];
            int pathLen = 0;
            Position trace = goal;
            while (!(trace == start)) {
                if (pathLen >= maxPathLen) break;
                pathBuffer[pathLen++] = trace;
                trace = cameFrom[trace.y * width + trace.x];
            }
            pathBuffer[pathLen++] = start;

            for (int i = 0; i < pathLen; i++) {
                gpuData.d_agentPaths[agentID * maxPathLen + i] = pathBuffer[pathLen - i - 1];
            }
            gpuData.d_agentPathSizes[agentID] = pathLen;
        });
    }).wait();

    // **Kop�rovanie v�sledkov z GPU -> CPU**
    q.memcpy(m.agentPaths, gpuData.d_agentPaths, m.agentCount * m.width * m.height * sizeof(Position));
    q.memcpy(m.agentPathSizes, gpuData.d_agentPathSizes, m.agentCount * sizeof(int)).wait();
}


*/