/*
// n�vrch diinjkstra
// ========================================
#include <sycl/sycl.hpp>
#include <limits>
#include <vector>

#define INF std::numeric_limits<int>::max()

using namespace sycl;

struct Position {
    int x, y;
    bool operator==(const Position& other) const { return x == other.x && y == other.y; }
};

struct Agent {
    Position position;
    Position goal;
};

struct Map {
    int width, height;
    char* grid;  // Device memory
    Position* agentPaths;
    int* agentPathSizes;
};

struct MinHeap {
    Position* heap;
    int* costs;
    int size;

    MinHeap(Position* h, int* c) : heap(h), costs(c), size(0) {}

    void push(Position p, int cost) {
        int i = size++;
        while (i > 0) {
            int parent = (i - 1) / 2;
            if (costs[heap[parent].y * 256 + heap[parent].x] <= cost) break;
            heap[i] = heap[parent];
            i = parent;
        }
        heap[i] = p;
    }

    Position pop() {
        Position top = heap[0];
        Position last = heap[--size];
        int i = 0;
        while (2 * i + 1 < size) {
            int child = 2 * i + 1;
            if (child + 1 < size && costs[heap[child + 1].y * 256 + heap[child + 1].x] < costs[heap[child].y * 256 + heap[child].x])
                child++;
            if (costs[last.y * 256 + last.x] <= costs[heap[child].y * 256 + heap[child].x]) break;
            heap[i] = heap[child];
            i = child;
        }
        heap[i] = last;
        return top;
    }

    bool empty() { return size == 0; }
};

void dijkstraGPU(queue& q, Map& map, Agent* agents, int agentCount) {
    buffer<char, 1> gridBuf(map.grid, range<1>(map.width * map.height));
    buffer<Position, 1> pathBuf(map.agentPaths, range<1>(agentCount * map.width * map.height));
    buffer<int, 1> pathSizeBuf(map.agentPathSizes, range<1>(agentCount));

    q.submit([&](handler& h) {
        accessor grid(gridBuf, h, read_only);
        accessor path(pathBuf, h, write_only, no_init);
        accessor pathSizes(pathSizeBuf, h, write_only);

        h.parallel_for(agentCount, [=](id<1> agentID) {
            Position start = agents[agentID].position;
            Position goal = agents[agentID].goal;

            int width = map.width;
            int height = map.height;
            int maxPathLen = width * height;

            int g_costs[256 * 256];
            bool visited[256 * 256] = {false};
            Position openList[256 * 256];

            for (int i = 0; i < width * height; i++) g_costs[i] = INF;
            g_costs[start.y * width + start.x] = 0;

            MinHeap heap(openList, g_costs);
            heap.push(start, 0);

            Position directions[4] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
            Position cameFrom[256 * 256];

            while (!heap.empty()) {
                Position current = heap.pop();
                if (visited[current.y * width + current.x]) continue;
                visited[current.y * width + current.x] = true;

                if (current == goal) break;

                for (int i = 0; i < 4; i++) {
                    Position neighbor = {current.x + directions[i].x, current.y + directions[i].y};
                    if (neighbor.x < 0 || neighbor.x >= width || neighbor.y < 0 || neighbor.y >= height) continue;
                    if (grid[neighbor.y * width + neighbor.x] == '#') continue;

                    int new_cost = g_costs[current.y * width + current.x] + 1;
                    if (new_cost < g_costs[neighbor.y * width + neighbor.x]) {
                        g_costs[neighbor.y * width + neighbor.x] = new_cost;
                        cameFrom[neighbor.y * width + neighbor.x] = current;
                        heap.push(neighbor, new_cost);
                    }
                }
            }

            Position pathBuffer[256 * 256];
            int pathLen = 0;
            Position trace = goal;
            while (!(trace == start)) {
                if (pathLen >= maxPathLen) break;
                pathBuffer[pathLen++] = trace;
                trace = cameFrom[trace.y * width + trace.x];
            }
            pathBuffer[pathLen++] = start;

            for (int i = 0; i < pathLen; i++) {
                path[agentID * maxPathLen + i] = pathBuffer[pathLen - i - 1];
            }
            pathSizes[agentID] = pathLen;
        });
    }).wait();
}

*/