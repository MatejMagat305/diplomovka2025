#pragma once
#include "map.h"

enum class AlgorithmType {
    ASTAR,
    // DIJKSTRA TODO later
};

double computeCPU(AlgorithmType which, Map& m, int numThreads);
double computeSYCL(AlgorithmType which, Map& m);
